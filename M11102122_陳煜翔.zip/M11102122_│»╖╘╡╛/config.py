Image_Path = r".\0.jpg"
q_k = 255
q_o = 0